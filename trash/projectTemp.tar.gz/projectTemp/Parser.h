#ifndef PARSER_H_
#define PARSER_H_
//Work in progress
class Parser{

private:


public:

	Query
};

#endif
