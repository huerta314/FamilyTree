#ifndef EDGE_H_
#define EDGE_H_

class Edge{

private:
	string factName;// Father, or Apple, etc
	Node* nextName;


public:

	int setName(string n); //set n to factName
	string getName(); //get factName

	Edge();
	Edge(string n, Node* np);
	//copy constructor, move constructor, assignment operator
	Edge(Edge& other);

	~Edge();
		
};
#endif

