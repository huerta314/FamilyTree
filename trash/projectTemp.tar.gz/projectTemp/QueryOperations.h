#ifndef QUERY_OPERATIONS_H_
#define QUERY_OPERATIOSN_H_

#include "Dumper.h"
#include "KnowledgeBase.h"
#include "RuleBase.h"
#include "Query.h"

class QueryOperations{

private:
	Dumper dumper;
	KnowledgeBase kb;
	RuleBase rb;


public:
	int Add(Query query);
	int Remove(Query query);

	int Inference(Query query);
	int Dump(Query query);
	int Load(Query query);

};
#endif
